"""
Enterprise-grade styling utilities for the quantum control dashboard.
Provides consistent styling, colors, and UI components.
"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px

class EnterpriseTheme:
    """Professional dark theme color scheme and styling constants."""
    
    # Color palette - Professional black theme
    PRIMARY = "#ffffff"
    SECONDARY = "#000000"
    ACCENT = "#666666"
    SUCCESS = "#00ff88"
    WARNING = "#ffaa00"
    ERROR = "#ff4444"
    INFO = "#00aaff"
    
    # Background colors - Deep black theme
    BG_PRIMARY = "#000000"
    BG_SECONDARY = "#0a0a0a"
    BG_CARD = "#1a1a1a"
    BG_ACCENT = "#2a2a2a"
    
    # Text colors - High contrast
    TEXT_PRIMARY = "#ffffff"
    TEXT_SECONDARY = "#cccccc"
    TEXT_MUTED = "#888888"
    
    # Status colors - Bright on dark
    STATUS_OPERATIONAL = "#00ff88"
    STATUS_WARNING = "#ffaa00"
    STATUS_CRITICAL = "#ff4444"
    STATUS_MAINTENANCE = "#00aaff"
    
    # Chart colors - Professional palette
    CHART_COLORS = [
        "#ffffff", "#00ff88", "#ffaa00", "#ff4444", 
        "#00aaff", "#ff88ff", "#88ffff", "#ffff88"
    ]

def apply_enterprise_style():
    """Apply professional black theme CSS styling to the Streamlit app."""
    st.markdown("""
    <style>
    /* Import Professional Fonts */
    @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap');
    
    /* Global styles - Pure black theme */
    .stApp {
        font-family: 'Inter', sans-serif;
        background: #000000;
        color: #ffffff;
    }
    
    /* Remove default Streamlit styling */
    .stApp > header {
        background: transparent;
    }
    
    /* Main content area */
    .main .block-container {
        background: #000000;
        padding-top: 1rem;
    }
    
    /* Header styling - Professional black */
    .main-header {
        background: linear-gradient(135deg, #000000 0%, #1a1a1a 100%);
        padding: 2rem;
        border-radius: 16px;
        border: 1px solid #333333;
        margin-bottom: 2rem;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.8);
    }
    
    /* Card styling - Sleek black cards */
    .metric-card {
        background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
        padding: 1.5rem;
        border-radius: 12px;
        border: 1px solid #333333;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.5);
        margin-bottom: 1rem;
        transition: all 0.3s ease;
    }
    
    .metric-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 32px rgba(255, 255, 255, 0.1);
        border-color: #ffffff;
    }
    
    /* Status indicators - High contrast */
    .status-operational {
        color: #00ff88;
        font-weight: 600;
        text-shadow: 0 0 8px rgba(0, 255, 136, 0.5);
    }
    
    .status-warning {
        color: #ffaa00;
        font-weight: 600;
        text-shadow: 0 0 8px rgba(255, 170, 0, 0.5);
    }
    
    .status-critical {
        color: #ff4444;
        font-weight: 600;
        text-shadow: 0 0 8px rgba(255, 68, 68, 0.5);
    }
    
    .status-maintenance {
        color: #00aaff;
        font-weight: 600;
        text-shadow: 0 0 8px rgba(0, 170, 255, 0.5);
    }
    
    /* Custom buttons - Professional black theme */
    .stButton > button {
        background: linear-gradient(135deg, #1a1a1a 0%, #333333 100%);
        border: 1px solid #666666;
        border-radius: 8px;
        color: #ffffff;
        font-weight: 500;
        padding: 0.5rem 1.5rem;
        transition: all 0.3s ease;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
    }
    
    .stButton > button:hover {
        background: linear-gradient(135deg, #333333 0%, #4a4a4a 100%);
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(255, 255, 255, 0.1);
        border-color: #ffffff;
    }
    
    /* Sidebar styling - Pure black */
    .css-1d391kg, section[data-testid="stSidebar"] > div {
        background: linear-gradient(180deg, #000000 0%, #0a0a0a 100%);
        border-right: 1px solid #333333;
    }
    
    /* Sidebar content styling */
    .css-1d391kg .css-1v0mbdj {
        background: transparent;
    }
    
    /* Metrics styling - Professional black */
    .metric-container {
        background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
        padding: 1rem;
        border-radius: 8px;
        border: 1px solid #333333;
        text-align: center;
    }
    
    /* Alert styling - High contrast */
    .alert-success {
        background: linear-gradient(135deg, #001a11 0%, #003322 100%);
        border: 1px solid #00ff88;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
        color: #00ff88;
    }
    
    .alert-warning {
        background: linear-gradient(135deg, #1a1100 0%, #332200 100%);
        border: 1px solid #ffaa00;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
        color: #ffaa00;
    }
    
    .alert-error {
        background: linear-gradient(135deg, #1a0808 0%, #330f0f 100%);
        border: 1px solid #ff4444;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
        color: #ff4444;
    }
    
    .alert-info {
        background: linear-gradient(135deg, #001122 0%, #002244 100%);
        border: 1px solid #00aaff;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
        color: #00aaff;
    }
    
    /* Table styling - Dark theme */
    .stDataFrame {
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid #333333;
        background: #0a0a0a;
    }
    
    /* Progress bars - Professional styling */
    .stProgress .st-bo {
        background: #1a1a1a;
    }
    
    .stProgress .st-bp {
        background: linear-gradient(90deg, #ffffff 0%, #cccccc 100%);
    }
    
    /* Custom classes for professional components */
    .enterprise-title {
        font-size: 2.5rem;
        font-weight: 700;
        color: #ffffff;
        text-shadow: 0 0 20px rgba(255, 255, 255, 0.3);
        margin-bottom: 0.5rem;
        letter-spacing: 2px;
    }
    
    .enterprise-subtitle {
        font-size: 1.125rem;
        color: #cccccc;
        font-weight: 400;
        margin-bottom: 2rem;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    .system-status-good {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        background: linear-gradient(135deg, #001a11 0%, #003322 100%);
        color: #00ff88;
        border: 1px solid #00ff88;
        border-radius: 9999px;
        font-size: 0.875rem;
        font-weight: 500;
        text-shadow: 0 0 8px rgba(0, 255, 136, 0.5);
    }
    
    .system-status-warning {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        background: linear-gradient(135deg, #1a1100 0%, #332200 100%);
        color: #ffaa00;
        border: 1px solid #ffaa00;
        border-radius: 9999px;
        font-size: 0.875rem;
        font-weight: 500;
        text-shadow: 0 0 8px rgba(255, 170, 0, 0.5);
    }
    
    .system-status-critical {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        background: linear-gradient(135deg, #1a0808 0%, #330f0f 100%);
        color: #ff4444;
        border: 1px solid #ff4444;
        border-radius: 9999px;
        font-size: 0.875rem;
        font-weight: 500;
        text-shadow: 0 0 8px rgba(255, 68, 68, 0.5);
    }
    
    /* Scrollbar styling - Black theme */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: #000000;
    }
    
    ::-webkit-scrollbar-thumb {
        background: #333333;
        border-radius: 4px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: #666666;
    }
    
    /* Additional Streamlit component styling */
    .stSelectbox > div > div {
        background: #0a0a0a;
        border: 1px solid #333333;
        color: #ffffff;
    }
    
    .stTextInput > div > div > input {
        background: #0a0a0a;
        border: 1px solid #333333;
        color: #ffffff;
    }
    
    .stSlider > div > div > div {
        background: #1a1a1a;
    }
    
    /* Remove Streamlit branding and styling */
    .stApp > footer {
        visibility: hidden;
    }
    
    .stApp > header {
        visibility: hidden;
    }
    
    MainMenu {
        visibility: hidden;
    }
    
    /* Animation classes */
    .fade-in {
        animation: fadeIn 0.5s ease-in;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .pulse {
        animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }
    
    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: .5; }
    }
    </style>
    """, unsafe_allow_html=True)

def create_enterprise_metric_card(title: str, value: str, delta: str = "", delta_color: str = "normal"):
    """Create an enterprise-styled metric card."""
    delta_class = ""
    if delta and delta != "":
        if delta_color == "normal":
            delta_class = "status-operational" if delta.startswith('+') else "status-critical"
        elif delta_color == "inverse":
            delta_class = "status-critical" if delta.startswith('+') else "status-operational"
    
    delta_html = f'<div class="{delta_class}">{delta}</div>' if delta and delta != "" else ""
    
    return f"""
    <div class="metric-card">
        <div style="font-size: 0.875rem; color: #9ca3af; margin-bottom: 0.5rem;">{title}</div>
        <div style="font-size: 2rem; font-weight: 700; color: #ffffff; margin-bottom: 0.25rem;">{value}</div>
        {delta_html}
    </div>
    """

def create_status_badge(status: str, text: str = ""):
    """Create a status badge with enterprise styling."""
    if text == "":
        text = status
    
    status_classes = {
        "operational": "system-status-good",
        "warning": "system-status-warning", 
        "critical": "system-status-critical",
        "good": "system-status-good",
        "maintenance": "system-status-warning"
    }
    
    css_class = status_classes.get(status.lower(), "system-status-good")
    return f'<span class="{css_class}">{text}</span>'

def get_enterprise_plotly_theme():
    """Get professional black theme Plotly configuration."""
    return {
        'layout': {
            'plot_bgcolor': '#000000',
            'paper_bgcolor': '#000000',
            'font': {
                'family': 'Inter, sans-serif',
                'color': '#ffffff',
                'size': 12
            },
            'colorway': EnterpriseTheme.CHART_COLORS,
            'xaxis': {
                'gridcolor': '#333333',
                'linecolor': '#666666',
                'tickcolor': '#888888',
                'zerolinecolor': '#666666',
                'color': '#ffffff'
            },
            'yaxis': {
                'gridcolor': '#333333', 
                'linecolor': '#666666',
                'tickcolor': '#888888',
                'zerolinecolor': '#666666',
                'color': '#ffffff'
            },
            'legend': {
                'bgcolor': 'rgba(10, 10, 10, 0.9)',
                'bordercolor': '#333333',
                'borderwidth': 1,
                'font': {'color': '#ffffff'}
            }
        }
    }

def create_enterprise_header(title: str, subtitle: str = "", status: str = ""):
    """Create an enterprise-styled header."""
    status_html = ""
    if status and status != "":
        status_html = f'<div style="margin-top: 1rem;">{create_status_badge(status)}</div>'
    
    subtitle_html = ""
    if subtitle and subtitle != "":
        subtitle_html = f'<div class="enterprise-subtitle">{subtitle}</div>'
    
    return f"""
    <div class="main-header fade-in">
        <div class="enterprise-title">{title}</div>
        {subtitle_html}
        {status_html}
    </div>
    """

def create_alert_box(message: str, alert_type: str = "info", icon: str = ""):
    """Create an enterprise-styled alert box."""
    icons = {
        "success": "✓",
        "warning": "⚠",
        "error": "✕",
        "info": "ℹ"
    }
    
    if icon == "":
        icon = icons.get(alert_type, "ℹ")
    
    alert_class = f"alert-{alert_type}"
    
    return f"""
    <div class="{alert_class}">
        <span style="margin-right: 0.5rem; font-weight: 600;">{icon}</span>
        {message}
    </div>
    """
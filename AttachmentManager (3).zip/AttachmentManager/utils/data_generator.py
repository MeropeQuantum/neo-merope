"""
Data generation utilities for the QuantumOS Enterprise Control Platform.
Generates realistic quantum telemetry and system data for dashboard visualization.
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
import random

class DataGenerator:
    """Generates realistic quantum system data for dashboard visualization."""
    
    def __init__(self, num_qubits: int = 8):
        self.num_qubits = num_qubits
        self.base_frequencies = np.linspace(4.3, 5.7, num_qubits)
        self.random_state = np.random.RandomState(42)  # For reproducible results
        
    def generate_qubit_telemetry(self, num_points: int = 100, hours: int = 24) -> pd.DataFrame:
        """Generate realistic qubit telemetry data over time."""
        data = []
        end_time = datetime.now()
        start_time = end_time - timedelta(hours=hours)
        
        time_points = pd.date_range(start=start_time, end=end_time, periods=num_points)
        
        for timestamp in time_points:
            for qubit_id in range(self.num_qubits):
                # Base parameters with realistic variations
                base_freq = self.base_frequencies[qubit_id]
                
                # Add temporal drift and noise
                time_factor = (timestamp - start_time).total_seconds() / (hours * 3600)
                freq_drift = 0.001 * np.sin(2 * np.pi * time_factor * 3)  # Slow drift
                frequency = base_freq + freq_drift + self.random_state.normal(0, 0.0005)
                
                # Coherence times with realistic correlation
                t1_base = 120 + qubit_id * 5 + 20 * np.sin(2 * np.pi * time_factor * 2)
                t1_coherence = max(t1_base + self.random_state.normal(0, 15), 50)
                
                t2_coherence = min(t1_coherence * 0.7, 85) + self.random_state.normal(0, 8)
                t2_coherence = max(t2_coherence, 30)
                
                # Fidelities with temperature correlation
                temp_variation = 0.002 * np.sin(2 * np.pi * time_factor * 5)
                base_temp = 0.015 + temp_variation
                temperature_mk = max(base_temp + self.random_state.normal(0, 0.001), 0.010)
                
                # Temperature affects fidelity
                temp_penalty = max(0, (temperature_mk - 0.015) * 100)
                gate_fidelity = 99.5 - temp_penalty + self.random_state.normal(0, 0.2)
                readout_fidelity = 99.2 - temp_penalty * 0.8 + self.random_state.normal(0, 0.3)
                
                # Determine status based on performance
                status = 'operational'
                if gate_fidelity < 99.0 or readout_fidelity < 98.5:
                    status = 'degraded'
                elif gate_fidelity < 98.0 or t1_coherence < 80:
                    status = 'maintenance_required'
                
                data.append({
                    'timestamp': timestamp,
                    'qubit_id': qubit_id,
                    'frequency_ghz': round(frequency, 6),
                    't1_coherence_us': round(t1_coherence, 1),
                    't2_coherence_us': round(t2_coherence, 1),
                    'gate_fidelity_percent': round(np.clip(gate_fidelity, 95, 100), 2),
                    'readout_fidelity_percent': round(np.clip(readout_fidelity, 95, 100), 2),
                    'temperature_mk': round(temperature_mk, 6),
                    'status': status
                })
        
        return pd.DataFrame(data)
    
    def generate_system_metrics(self, num_points: int = 100, hours: int = 24) -> pd.DataFrame:
        """Generate system performance metrics over time."""
        data = []
        end_time = datetime.now()
        start_time = end_time - timedelta(hours=hours)
        
        time_points = pd.date_range(start=start_time, end=end_time, periods=num_points)
        
        for timestamp in time_points:
            time_factor = (timestamp - start_time).total_seconds() / (hours * 3600)
            
            # System load varies throughout the day
            daily_cycle = np.sin(2 * np.pi * time_factor) * 0.3 + 0.5  # 0.2 to 0.8
            
            uptime_percent = 99.8 + self.random_state.normal(0, 0.1)
            error_rate = 0.3 + 0.4 * (1 - daily_cycle) + self.random_state.normal(0, 0.1)
            
            queue_length = int(10 * daily_cycle + self.random_state.normal(0, 2))
            active_jobs = min(queue_length, 8) + self.random_state.randint(-1, 2)
            
            cpu_usage = 40 + 30 * daily_cycle + self.random_state.normal(0, 5)
            memory_usage = 35 + 25 * daily_cycle + self.random_state.normal(0, 4)
            network_io = 8 + 6 * daily_cycle + self.random_state.normal(0, 2)
            
            data.append({
                'timestamp': timestamp,
                'uptime_percent': round(np.clip(uptime_percent, 95, 100), 2),
                'error_rate_percent': round(max(error_rate, 0), 2),
                'queue_length': max(queue_length, 0),
                'active_jobs': max(active_jobs, 0),
                'cpu_usage_percent': round(np.clip(cpu_usage, 0, 100), 1),
                'memory_usage_percent': round(np.clip(memory_usage, 0, 100), 1),
                'network_io_mbps': round(max(network_io, 0), 1)
            })
        
        return pd.DataFrame(data)
    
    def generate_temperature_data(self, num_points: int = 100, hours: int = 24) -> pd.DataFrame:
        """Generate cryogenic temperature data."""
        stages = {
            'mixing_chamber': {'base': 0.015, 'variation': 0.002, 'threshold': 0.025},
            'still': {'base': 0.7, 'variation': 0.05, 'threshold': 1.0},
            '4k': {'base': 4.2, 'variation': 0.3, 'threshold': 5.0},
            '50k': {'base': 52.0, 'variation': 3.0, 'threshold': 60.0}
        }
        
        data = []
        end_time = datetime.now()
        start_time = end_time - timedelta(hours=hours)
        
        time_points = pd.date_range(start=start_time, end=end_time, periods=num_points)
        
        for timestamp in time_points:
            time_factor = (timestamp - start_time).total_seconds() / (hours * 3600)
            
            for stage, params in stages.items():
                # Add thermal cycling and noise
                cycle_factor = np.sin(2 * np.pi * time_factor * 0.5) * 0.1  # Slow thermal cycle
                temperature = (params['base'] + 
                             cycle_factor * params['base'] + 
                             self.random_state.normal(0, params['variation'] * 0.3))
                
                temperature = max(temperature, params['base'] * 0.5)
                status = 'normal' if temperature < params['threshold'] else 'warning'
                
                data.append({
                    'timestamp': timestamp,
                    'stage': stage,
                    'temperature_k': round(temperature, 6),
                    'status': status
                })
        
        return pd.DataFrame(data)
    
    def generate_pulse_sequences(self, num_sequences: int = 50) -> pd.DataFrame:
        """Generate pulse sequence execution data."""
        sequence_types = [
            'single_qubit_x', 'single_qubit_y', 'single_qubit_z',
            'cnot', 'cz', 'swap', 'toffoli',
            'hadamard', 'phase_gate', 'custom_gate'
        ]
        
        data = []
        end_time = datetime.now()
        
        for i in range(num_sequences):
            timestamp = end_time - timedelta(hours=self.random_state.uniform(0, 72))
            sequence_name = self.random_state.choice(sequence_types)
            
            # Number of target qubits depends on gate type
            if 'single' in sequence_name:
                num_targets = 1
            elif sequence_name in ['cnot', 'cz', 'swap']:
                num_targets = 2
            elif sequence_name == 'toffoli':
                num_targets = 3
            else:
                num_targets = self.random_state.randint(1, 4)
            
            target_qubits = sorted(self.random_state.choice(
                self.num_qubits, size=num_targets, replace=False
            ).tolist())
            
            # Generate pulse parameters
            duration = self.random_state.uniform(10, 50)  # nanoseconds
            amplitude = self.random_state.uniform(0.1, 1.0)
            frequency = self.random_state.uniform(4.0, 6.0)
            
            pulse_params = {
                'duration': round(duration, 1),
                'amplitude': round(amplitude, 3),
                'frequency_ghz': round(frequency, 3),
                'phase': round(self.random_state.uniform(0, 2*np.pi), 3)
            }
            
            # Predicted vs actual fidelity
            predicted_fidelity = 99.0 + self.random_state.uniform(0, 0.8)
            actual_fidelity = predicted_fidelity + self.random_state.normal(0, 0.3)
            
            execution_time = duration * len(target_qubits) * (1 + self.random_state.uniform(0, 0.2))
            
            status = self.random_state.choice(['completed', 'failed'], p=[0.95, 0.05])
            if status == 'failed':
                actual_fidelity = self.random_state.uniform(85, 95)
            
            data.append({
                'timestamp': timestamp,
                'sequence_name': sequence_name,
                'target_qubits': target_qubits,
                'pulse_parameters': pulse_params,
                'predicted_fidelity': round(predicted_fidelity, 2),
                'actual_fidelity': round(np.clip(actual_fidelity, 85, 100), 2),
                'execution_time_ns': round(execution_time, 1),
                'status': status
            })
        
        return pd.DataFrame(data).sort_values('timestamp', ascending=False)
    
    def generate_quantum_states(self, num_states: int = 30) -> pd.DataFrame:
        """Generate quantum state snapshots."""
        state_types = [
            '|0⟩', '|1⟩', '|+⟩', '|-⟩', '|+i⟩', '|-i⟩',
            'Bell_00', 'Bell_01', 'Bell_10', 'Bell_11',
            'GHZ', 'W_state', 'random'
        ]
        
        data = []
        end_time = datetime.now()
        
        for i in range(num_states):
            timestamp = end_time - timedelta(hours=self.random_state.uniform(0, 48))
            state_name = self.random_state.choice(state_types)
            
            if 'Bell' in state_name or 'GHZ' in state_name or 'W_state' in state_name:
                num_qubits = 2 if 'Bell' in state_name else self.random_state.randint(3, 5)
            else:
                num_qubits = 1
            
            # Generate state vector (simplified representation)
            if state_name == '|0⟩':
                state_vector = [1.0, 0.0]
            elif state_name == '|1⟩':
                state_vector = [0.0, 1.0]
            elif state_name == '|+⟩':
                state_vector = [0.707, 0.707]
            elif state_name == '|-⟩':
                state_vector = [0.707, -0.707]
            else:
                # Random state
                dim = 2 ** num_qubits
                amplitudes = self.random_state.normal(0, 1, dim) + 1j * self.random_state.normal(0, 1, dim)
                amplitudes = amplitudes / np.linalg.norm(amplitudes)
                state_vector = [{'real': amp.real, 'imag': amp.imag} for amp in amplitudes]
            
            # Calculate fidelity, purity, etc.
            fidelity = 99.0 + self.random_state.uniform(0, 1.0)
            purity = 0.95 + self.random_state.uniform(0, 0.05)
            
            if num_qubits > 1:
                entanglement_entropy = self.random_state.uniform(0, np.log(2) * (num_qubits - 1))
            else:
                entanglement_entropy = 0.0
            
            # Generate measurement results
            measurements = {}
            for qubit in range(num_qubits):
                measurements[f'qubit_{qubit}'] = {
                    'basis': self.random_state.choice(['Z', 'X', 'Y']),
                    'result': self.random_state.choice([0, 1]),
                    'probability': self.random_state.uniform(0.8, 1.0)
                }
            
            data.append({
                'timestamp': timestamp,
                'state_name': state_name,
                'num_qubits': num_qubits,
                'state_vector': state_vector,
                'fidelity': round(fidelity, 2),
                'purity': round(purity, 3),
                'entanglement_entropy': round(entanglement_entropy, 3),
                'measurement_results': measurements
            })
        
        return pd.DataFrame(data).sort_values('timestamp', ascending=False)
    
    def generate_calibration_data(self, num_runs: int = 20) -> pd.DataFrame:
        """Generate calibration run data."""
        calibration_types = [
            'frequency_calibration', 'readout_calibration', 'gate_calibration',
            'cross_talk_calibration', 'coherence_optimization', 'pulse_optimization'
        ]
        
        data = []
        end_time = datetime.now()
        
        for i in range(num_runs):
            timestamp = end_time - timedelta(days=self.random_state.uniform(0, 30))
            cal_type = self.random_state.choice(calibration_types)
            
            # Number of qubits involved
            if 'cross_talk' in cal_type:
                num_targets = self.random_state.randint(2, 4)
            else:
                num_targets = self.random_state.randint(1, 3)
            
            target_qubits = sorted(self.random_state.choice(
                self.num_qubits, size=num_targets, replace=False
            ).tolist())
            
            # Generate before/after parameters
            if 'frequency' in cal_type:
                param_key = 'frequency_ghz'
                before_val = 4.5 + self.random_state.normal(0, 0.01)
                improvement = self.random_state.uniform(0.001, 0.005)
            elif 'readout' in cal_type:
                param_key = 'readout_fidelity'
                before_val = 98.5 + self.random_state.normal(0, 0.5)
                improvement = self.random_state.uniform(0.2, 0.8)
            else:
                param_key = 'gate_fidelity'
                before_val = 98.8 + self.random_state.normal(0, 0.3)
                improvement = self.random_state.uniform(0.1, 0.6)
            
            parameters_before = {param_key: round(before_val, 3)}
            parameters_after = {param_key: round(before_val + improvement, 3)}
            
            improvement_metrics = {
                'improvement_percent': round((improvement / before_val) * 100, 2),
                'standard_deviation_reduction': self.random_state.uniform(0.1, 0.3)
            }
            
            duration = self.random_state.uniform(15, 120)  # minutes
            status = self.random_state.choice(['completed', 'partial'], p=[0.9, 0.1])
            
            notes = f"Automated {cal_type} on qubits {target_qubits}"
            if status == 'partial':
                notes += " - convergence criteria not fully met"
            
            data.append({
                'timestamp': timestamp,
                'calibration_type': cal_type,
                'target_qubits': target_qubits,
                'parameters_before': parameters_before,
                'parameters_after': parameters_after,
                'improvement_metrics': improvement_metrics,
                'duration_minutes': round(duration, 1),
                'status': status,
                'notes': notes
            })
        
        return pd.DataFrame(data).sort_values('timestamp', ascending=False)

# Global instance for easy access
data_generator = DataGenerator()
# QuantumOS Enterprise Control Platform

A sophisticated Streamlit-based quantum computing dashboard with PostgreSQL backend, built with Poetry for dependency management and Docker for containerized deployment.

## 🚀 Quick Start with Docker

### Prerequisites
- Docker 24.0+ and Docker Compose 2.0+
- 4GB+ RAM available for containers

### Run the Application

```bash
# Clone and start the full stack
git clone <repository-url>
cd quantumos-enterprise-platform

# Start services (PostgreSQL + QuantumOS Dashboard)
docker compose up

# Access the application
open http://localhost:8501
```

The application will be available at `http://localhost:8501` with PostgreSQL running on `localhost:5432`.

### Stop Services

```bash
docker compose down
```

## 📋 Architecture Overview

- **Frontend**: Streamlit dashboard with enterprise-grade UI
- **Backend**: PostgreSQL 15 with SQLAlchemy ORM
- **Language**: Python 3.12 with Poetry dependency management
- **Container**: Multi-stage Docker build with non-root user
- **Orchestration**: Docker Compose with health checks

## 🛠 Development Setup

### Prerequisites
- Python 3.12+
- Poetry 1.8+
- PostgreSQL 15+ (for local development)

### Local Development

```bash
# Install Poetry (if not already installed)
curl -sSL https://install.python-poetry.org | python3 -

# Install dependencies
make install

# Start development server
make dev

# Run tests
make test

# Code formatting and linting
make format
make lint
```

### Environment Variables

```bash
# Required for database connectivity
DATABASE_URL=postgresql://quantumos:quantum_secure_2024@localhost:5432/quantumos_db
PGHOST=localhost
PGPORT=5432
PGUSER=quantumos
PGPASSWORD=quantum_secure_2024
PGDATABASE=quantumos_db
```

## 🏗 Production Deployment

### Docker Production Build

```bash
# Build production image
docker build -f docker/Dockerfile -t quantumos-enterprise-platform:latest .

# Run with production settings
docker run -d \
  --name quantumos-app \
  -p 8501:8501 \
  -e DATABASE_URL=postgresql://user:pass@db:5432/quantumos_db \
  quantumos-enterprise-platform:latest
```

### Docker Compose Production

```bash
# Production deployment with environment overrides
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d
```

## 📦 Dependencies Management

This project uses Poetry with strict version bounds for dependency management:

### Core Dependencies
- **Python**: >=3.12,<3.14
- **Streamlit**: >=1.45.1,<2.0.0
- **PostgreSQL**: psycopg2-binary >=2.9.10,<3.0.0
- **Data Science**: pandas, numpy, scipy, plotly
- **Database**: SQLAlchemy >=2.0.41,<3.0.0, alembic

### Lock File Validation
```bash
# Verify lock file is current
make lock-check

# Update dependencies (with care)
poetry update
poetry lock
```

## 🔧 Development Commands

### Available Make Targets

```bash
make help           # Show all available commands
make install        # Install dependencies with Poetry
make dev            # Start development server
make test           # Run test suite with coverage
make lint           # Run code quality checks
make format         # Format code with black and isort
make docker-build   # Build Docker image
make docker-run     # Run with docker-compose
make docker-stop    # Stop docker-compose services
make clean          # Clean build artifacts
```

### Code Quality Standards

- **Black**: Code formatting (88 char line length)
- **isort**: Import sorting with black profile
- **flake8**: Linting with complexity checks
- **mypy**: Type checking (Python 3.12 target)
- **pytest**: Testing with coverage reporting

## 📊 Application Features

### Dashboard Pages
1. **Overview**: System status and key metrics
2. **Qubit Telemetry**: Real-time quantum bit monitoring
3. **Fidelity Monitor**: Gate and readout fidelity tracking
4. **Pulse Control**: Quantum pulse sequence management
5. **Quantum States**: State visualization and analysis
6. **System Status**: Infrastructure monitoring
7. **Database Management**: PostgreSQL operations and analytics

### Database Schema
- **QubitTelemetry**: Real-time quantum measurements
- **SystemMetrics**: Infrastructure performance data
- **CryogenicTemperatures**: Cooling system monitoring
- **PulseSequences**: Quantum gate operations
- **SystemAlerts**: Automated notifications
- **CalibrationRuns**: System optimization records
- **QuantumStates**: State snapshots and analysis

## 🔒 Security Features

- **Non-root container**: Application runs as `quantumos` user (UID 1000)
- **Multi-stage build**: Minimal production image
- **Health checks**: Application and database monitoring
- **Secret management**: Environment-based configuration
- **Network isolation**: Docker network segmentation

## 🧪 Testing

### Test Suite Execution

```bash
# Run all tests with coverage
make test

# Run specific test categories
poetry run pytest tests/unit/
poetry run pytest tests/integration/
poetry run pytest tests/e2e/
```

### Coverage Requirements
- Minimum 80% code coverage
- All critical paths tested
- Database integration tests included

## 📈 Monitoring & Observability

### Health Checks
- **Application**: `http://localhost:8501/_stcore/health`
- **Database**: PostgreSQL `pg_isready` checks
- **Container**: Built-in Docker health monitoring

### Logging
- Application logs: `/app/logs/`
- Database logs: Docker volume persistence
- Structured JSON logging for production

## 🚀 CI/CD Pipeline

### GitHub Actions Workflow
- **Code Quality**: Black, isort, flake8, mypy
- **Testing**: pytest with PostgreSQL service
- **Security**: Trivy vulnerability scanning
- **Container**: Multi-platform Docker builds
- **Deployment**: Automated production releases

### Lock File Enforcement
```yaml
# CI fails if poetry.lock is out of date
poetry lock --check
```

## 🔧 Troubleshooting

### Common Issues

**Database Connection Failed**
```bash
# Check PostgreSQL status
docker compose logs db

# Verify environment variables
echo $DATABASE_URL
```

**Import Errors**
```bash
# Reinstall dependencies
poetry install --no-cache

# Clear Python cache
make clean
```

**Container Build Issues**
```bash
# Clean Docker cache
make docker-clean

# Rebuild from scratch
docker build --no-cache -f docker/Dockerfile .
```

### Performance Tuning

**Database Optimization**
- Connection pooling configured
- Query optimization with indexes
- Prepared statements for frequent operations

**Application Scaling**
- Streamlit server configuration tuned
- Memory usage optimized
- Caching strategies implemented

## 📝 License

Enterprise License - See LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push branch: `git push origin feature/amazing-feature`
5. Open Pull Request

### Development Workflow
1. Run `make format lint test` before committing
2. Ensure `poetry lock --check` passes
3. Update documentation as needed
4. Add tests for new features

## 📞 Support

For technical support and deployment assistance:
- Documentation: `docs/`
- Issues: GitHub Issues
- Enterprise Support: Contact DevOps team

---

**Built with**: Python 3.12 • Poetry • Streamlit • PostgreSQL • Docker
"""
Database Management Page for QuantumOS Enterprise Control Platform.
Provides database administration, data management, and analytics tools.
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import numpy as np
from utils.styling import (
    apply_enterprise_style, create_enterprise_metric_card, 
    create_status_badge, get_enterprise_plotly_theme,
    create_enterprise_header, create_alert_box
)
from utils.db_integration import db_manager
from database.operations import quantum_db

# Page configuration
st.set_page_config(
    page_title="Database Management - QuantumOS",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Apply enterprise styling
apply_enterprise_style()

# Page header
create_enterprise_header(
    "Database Management",
    "PostgreSQL data storage, retrieval, and analytics for quantum telemetry",
    "🗄️"
)

# Sidebar controls
st.sidebar.markdown("### Database Controls")

# Data collection toggle
if st.sidebar.button("Start Data Collection", type="primary"):
    if db_manager.start_data_collection(interval_seconds=10):
        st.sidebar.success("Data collection started")
    else:
        st.sidebar.info("Data collection already running")

if st.sidebar.button("Stop Data Collection"):
    db_manager.stop_data_collection()
    st.sidebar.success("Data collection stopped")

# Database operations
st.sidebar.markdown("### Database Operations")
time_range = st.sidebar.selectbox(
    "Time Range",
    ["Last Hour", "Last 6 Hours", "Last 24 Hours", "Last Week"],
    index=2
)

# Convert time range to hours
time_mapping = {
    "Last Hour": 1,
    "Last 6 Hours": 6,
    "Last 24 Hours": 24,
    "Last Week": 168
}
hours = time_mapping[time_range]

# Initialize session state for data refresh
if 'db_data' not in st.session_state:
    st.session_state.db_data = None
if 'last_refresh' not in st.session_state:
    st.session_state.last_refresh = None

# Auto-refresh data
if st.sidebar.button("Refresh Data", type="secondary"):
    with st.spinner("Loading data from PostgreSQL..."):
        st.session_state.db_data = db_manager.get_dashboard_data(hours=hours)
        st.session_state.last_refresh = datetime.now()

# Load data if not already loaded
if st.session_state.db_data is None:
    with st.spinner("Loading data from PostgreSQL..."):
        st.session_state.db_data = db_manager.get_dashboard_data(hours=hours)
        st.session_state.last_refresh = datetime.now()

dashboard_data = st.session_state.db_data

# Data freshness indicator
if st.session_state.last_refresh:
    time_since_refresh = (datetime.now() - st.session_state.last_refresh).total_seconds()
    if time_since_refresh < 60:
        freshness_color = "green"
        freshness_text = f"Data refreshed {int(time_since_refresh)}s ago"
    elif time_since_refresh < 300:
        freshness_color = "orange"
        freshness_text = f"Data refreshed {int(time_since_refresh/60)}m ago"
    else:
        freshness_color = "red"
        freshness_text = f"Data refreshed {int(time_since_refresh/60)}m ago"
    
    st.sidebar.markdown(f"**Data Freshness:** :{freshness_color}[{freshness_text}]")

# Main content
if not dashboard_data:
    st.error("Unable to connect to database. Please check connection.")
    st.stop()

# Database statistics
col1, col2, col3, col4 = st.columns(4)

telemetry_df = dashboard_data.get('telemetry', pd.DataFrame())
metrics_df = dashboard_data.get('system_metrics', pd.DataFrame())
temp_df = dashboard_data.get('temperatures', pd.DataFrame())
alerts_df = dashboard_data.get('alerts', pd.DataFrame())

with col1:
    telemetry_count = len(telemetry_df)
    create_enterprise_metric_card(
        "Telemetry Records", 
        f"{telemetry_count:,}", 
        f"in {time_range.lower()}"
    )

with col2:
    metrics_count = len(metrics_df)
    create_enterprise_metric_card(
        "System Metrics", 
        f"{metrics_count:,}", 
        f"in {time_range.lower()}"
    )

with col3:
    temp_count = len(temp_df)
    create_enterprise_metric_card(
        "Temperature Records", 
        f"{temp_count:,}", 
        f"in {time_range.lower()}"
    )

with col4:
    alerts_count = len(alerts_df)
    create_enterprise_metric_card(
        "Active Alerts", 
        f"{alerts_count:,}", 
        "requiring attention"
    )

st.markdown("---")

# Data overview tabs
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "📊 Data Overview", "🔧 Qubit Telemetry", "📈 System Metrics", 
    "🌡️ Temperature Data", "⚠️ Alerts Management"
])

with tab1:
    st.markdown("### Database Data Overview")
    
    # Data distribution chart
    if not telemetry_df.empty:
        col1, col2 = st.columns(2)
        
        with col1:
            # Records per hour
            telemetry_df['hour'] = pd.to_datetime(telemetry_df['timestamp']).dt.floor('H')
            hourly_counts = telemetry_df.groupby('hour').size().reset_index(name='count')
            
            fig = px.bar(
                hourly_counts, 
                x='hour', 
                y='count',
                title="Telemetry Records per Hour",
                labels={'hour': 'Time', 'count': 'Record Count'}
            )
            fig.update_layout(get_enterprise_plotly_theme())
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Records per qubit
            qubit_counts = telemetry_df.groupby('qubit_id').size().reset_index(name='count')
            
            fig = px.bar(
                qubit_counts, 
                x='qubit_id', 
                y='count',
                title="Records per Qubit",
                labels={'qubit_id': 'Qubit ID', 'count': 'Record Count'}
            )
            fig.update_layout(get_enterprise_plotly_theme())
            st.plotly_chart(fig, use_container_width=True)
    
    # Health summary
    health_summary = dashboard_data.get('health_summary', {})
    if health_summary:
        st.markdown("### System Health Summary")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("**System Status**")
            system_data = health_summary.get('system', {})
            if system_data:
                st.metric("Uptime", f"{system_data.get('uptime_percent', 0):.1f}%")
                st.metric("Error Rate", f"{system_data.get('error_rate_percent', 0):.2f}%")
                st.metric("Active Jobs", f"{system_data.get('active_jobs', 0)}")
        
        with col2:
            st.markdown("**Qubit Status**")
            qubit_status = health_summary.get('qubit_status', {})
            for status, count in qubit_status.items():
                st.metric(status.replace('_', ' ').title(), count)
        
        with col3:
            st.markdown("**Alert Summary**")
            alert_counts = health_summary.get('alerts', {})
            for priority, count in alert_counts.items():
                color = {"critical": "red", "high": "orange", "medium": "yellow", "low": "green"}.get(priority, "gray")
                st.markdown(f":{color}[{priority.title()}: {count}]")

with tab2:
    st.markdown("### Qubit Telemetry Data")
    
    if not telemetry_df.empty:
        # Data summary
        st.markdown("#### Data Summary")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            avg_gate_fidelity = telemetry_df['gate_fidelity_percent'].mean()
            st.metric("Avg Gate Fidelity", f"{avg_gate_fidelity:.2f}%")
        
        with col2:
            avg_readout_fidelity = telemetry_df['readout_fidelity_percent'].mean()
            st.metric("Avg Readout Fidelity", f"{avg_readout_fidelity:.2f}%")
        
        with col3:
            avg_t1 = telemetry_df['t1_coherence_us'].mean()
            st.metric("Avg T1 Coherence", f"{avg_t1:.1f}μs")
        
        # Interactive data table
        st.markdown("#### Recent Telemetry Records")
        
        # Filter options
        col1, col2 = st.columns(2)
        with col1:
            selected_qubits = st.multiselect(
                "Filter by Qubit ID",
                options=sorted(telemetry_df['qubit_id'].unique()),
                default=[]
            )
        
        with col2:
            status_filter = st.multiselect(
                "Filter by Status",
                options=telemetry_df['status'].unique(),
                default=[]
            )
        
        # Apply filters
        filtered_df = telemetry_df.copy()
        if selected_qubits:
            filtered_df = filtered_df[filtered_df['qubit_id'].isin(selected_qubits)]
        if status_filter:
            filtered_df = filtered_df[filtered_df['status'].isin(status_filter)]
        
        # Display table
        st.dataframe(
            filtered_df.sort_values('timestamp', ascending=False).head(100),
            use_container_width=True,
            hide_index=True
        )
        
        # Download option
        if st.button("Download Telemetry Data (CSV)"):
            csv = filtered_df.to_csv(index=False)
            st.download_button(
                label="Download CSV",
                data=csv,
                file_name=f"qubit_telemetry_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
    else:
        st.info("No telemetry data found in the selected time range.")

with tab3:
    st.markdown("### System Metrics Data")
    
    if not metrics_df.empty:
        # System performance trend
        fig = go.Figure()
        
        metrics_df['timestamp'] = pd.to_datetime(metrics_df['timestamp'])
        metrics_df_sorted = metrics_df.sort_values('timestamp')
        
        fig.add_trace(go.Scatter(
            x=metrics_df_sorted['timestamp'],
            y=metrics_df_sorted['cpu_usage_percent'],
            name='CPU Usage (%)',
            line=dict(color='#00D4FF')
        ))
        
        fig.add_trace(go.Scatter(
            x=metrics_df_sorted['timestamp'],
            y=metrics_df_sorted['memory_usage_percent'],
            name='Memory Usage (%)',
            line=dict(color='#FF6B6B')
        ))
        
        fig.update_layout(
            title="System Resource Usage Over Time",
            xaxis_title="Time",
            yaxis_title="Usage (%)",
            **get_enterprise_plotly_theme()
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Metrics table
        st.markdown("#### Recent System Metrics")
        st.dataframe(
            metrics_df.sort_values('timestamp', ascending=False).head(50),
            use_container_width=True,
            hide_index=True
        )
    else:
        st.info("No system metrics data found in the selected time range.")

with tab4:
    st.markdown("### Temperature Monitoring Data")
    
    if not temp_df.empty:
        # Temperature trends by stage
        fig = go.Figure()
        
        temp_df['timestamp'] = pd.to_datetime(temp_df['timestamp'])
        
        for stage in temp_df['stage'].unique():
            stage_data = temp_df[temp_df['stage'] == stage].sort_values('timestamp')
            fig.add_trace(go.Scatter(
                x=stage_data['timestamp'],
                y=stage_data['temperature_k'],
                name=stage.replace('_', ' ').title(),
                mode='lines+markers'
            ))
        
        fig.update_layout(
            title="Cryogenic Temperature Monitoring",
            xaxis_title="Time",
            yaxis_title="Temperature (K)",
            yaxis_type="log",
            **get_enterprise_plotly_theme()
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Temperature status summary
        st.markdown("#### Temperature Status Summary")
        temp_status = temp_df.groupby(['stage', 'status']).size().unstack(fill_value=0)
        st.dataframe(temp_status, use_container_width=True)
        
        # Recent temperature data
        st.markdown("#### Recent Temperature Records")
        st.dataframe(
            temp_df.sort_values('timestamp', ascending=False).head(100),
            use_container_width=True,
            hide_index=True
        )
    else:
        st.info("No temperature data found in the selected time range.")

with tab5:
    st.markdown("### Alerts Management")
    
    if not alerts_df.empty:
        # Alert priority distribution
        col1, col2 = st.columns(2)
        
        with col1:
            priority_counts = alerts_df['priority'].value_counts()
            fig = px.pie(
                values=priority_counts.values,
                names=priority_counts.index,
                title="Alert Distribution by Priority"
            )
            fig.update_layout(get_enterprise_plotly_theme())
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            component_counts = alerts_df['component'].value_counts()
            fig = px.bar(
                x=component_counts.index,
                y=component_counts.values,
                title="Alerts by Component"
            )
            fig.update_layout(get_enterprise_plotly_theme())
            st.plotly_chart(fig, use_container_width=True)
        
        # Alert management interface
        st.markdown("#### Active Alerts")
        
        for idx, alert in alerts_df.iterrows():
            with st.expander(f"{alert['alert_type'].upper()}: {alert['message']}", expanded=False):
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.write(f"**Component:** {alert['component']}")
                    st.write(f"**Priority:** {alert['priority']}")
                
                with col2:
                    st.write(f"**Timestamp:** {alert['timestamp']}")
                    st.write(f"**Acknowledged:** {'Yes' if alert['acknowledged'] else 'No'}")
                
                with col3:
                    if not alert['acknowledged']:
                        if st.button(f"Acknowledge", key=f"ack_{alert['id']}"):
                            if quantum_db.acknowledge_alert(alert['id']):
                                st.success("Alert acknowledged")
                                st.rerun()
                            else:
                                st.error("Failed to acknowledge alert")
    else:
        st.info("No active alerts found.")

# Database maintenance section
st.markdown("---")
st.markdown("### Database Maintenance")

col1, col2, col3 = st.columns(3)

with col1:
    if st.button("Generate Sample Data"):
        with st.spinner("Generating sample data..."):
            # Generate and store sample data
            db_manager._collect_qubit_telemetry()
            db_manager._collect_system_metrics()
            db_manager._collect_temperature_readings()
            st.success("Sample data generated and stored")

with col2:
    if st.button("Database Health Check"):
        with st.spinner("Checking database health..."):
            try:
                # Simple health check
                recent_data = quantum_db.get_recent_qubit_telemetry(hours=1)
                if not recent_data.empty:
                    st.success(f"Database healthy - {len(recent_data)} recent records")
                else:
                    st.warning("Database connected but no recent data")
            except Exception as e:
                st.error(f"Database health check failed: {str(e)}")

with col3:
    if st.button("Get Calibration Recommendations"):
        with st.spinner("Analyzing data for recommendations..."):
            recommendations = db_manager.get_calibration_recommendations()
            if recommendations:
                st.success(f"Generated {len(recommendations)} recommendations")
                for rec in recommendations:
                    create_alert_box(
                        rec['reason'],
                        f"Recommended: {rec['type']} for qubits {rec['target_qubits']}",
                        rec['priority']
                    )
            else:
                st.info("No calibration recommendations at this time")

# Footer with database connection info
st.markdown("---")
st.markdown("**Database Connection:** PostgreSQL | **Status:** Connected | **Last Update:** " + 
           dashboard_data.get('data_timestamp', 'Unknown'))
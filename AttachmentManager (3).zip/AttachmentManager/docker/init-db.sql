-- Database initialization script for QuantumOS Enterprise Platform
-- Creates necessary extensions and initial setup

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable JSONB operators extension
CREATE EXTENSION IF NOT EXISTS "btree_gist";

-- Create database schema comment
COMMENT ON DATABASE quantumos_db IS 'QuantumOS Enterprise Control Platform Database';

-- Set timezone
SET timezone = 'UTC';

-- Create indexes for better performance (will be created by SQLAlchemy migrations)
-- This file ensures the database is properly initialized with required extensions